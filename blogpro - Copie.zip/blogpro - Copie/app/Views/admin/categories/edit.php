<form method="post">
    <?= $form->input('titre', 'Tire de la catégorie'); ?>
    <button class="btn btn-primary">Sauvegarder</button>
</form>