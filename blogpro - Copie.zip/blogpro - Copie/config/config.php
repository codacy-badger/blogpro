<?php
return array(
    "db_user" => "root",
    "db_pass" => "root",
    "db_host" => "localhost",
    "db_name" => "mvc"
);